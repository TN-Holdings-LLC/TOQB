# TOQB loop standard run 2 n6 L8 (seed 1138): for the same money, which compiler returns the best model?

Device fake:FakeFez; front end qiskit; task {"n": 6, "layers": 8, "enc": 1.5707963267948966, "teacher_seed": 4, "teacher_gap": 0.2, "n_train": 64, "n_test": 48}; optimizer {"name": "SPSA", "iterations": 200, "batch": 16, "a": 10.0, "c": 0.4, "A": 2, "init": 0.5, "loop_seed": 1138}; evaluation {"shots": 400, "shot_seed": 20261015, "every": 20, "target_accuracy": 0.7}.

Price: 0.00027 s per shot + 0.036 s per circuit + the circuit's duration per shot, at $1.60 per QPU second (rate: PSF-Zero TIME1 / FRAC1 on ibm_fez (2026-10-14); price: IBM Pay-As-You-Go, 'starts at $96 USD / minute', billed per second (ibm.com/quantum/pricing, 2026-10-15)).

Budget: batch $1626.17, session $1661.14 (what the reference arm qiskit:2:target:template spent on the whole training, plus 5%).

## 1. The result for the money

Accuracy / margin on the test set at the last evaluation within the budget (iteration in brackets); dollars to reach accuracy 0.7; noiseless accuracy of the final angles.

| arm | valid | batch: within budget | session: within budget | $ to target (batch / session) | spent on the whole training (batch / session) | final noiseless accuracy |
|---|---|---|---|---|---|---|
| psfai:template | yes | 0.823 / 0.311 (200) | 0.823 / 0.311 (200) | $604.10 / $621.38 | $1510.24 / $1553.95 | 0.792 |
| qiskit:2:target:template | yes | 0.740 / 0.238 (200) | 0.740 / 0.238 (200) | $154.87 / $158.24 | $1548.73 / $1582.04 | 0.688 |

## 2. Reference: classical models, and energy

Not a contest: TOQB compares compilers. The classical models (`toqb.classical`, numpy only, one fixed configuration each) are trained on the same training points and scored on the same test points, as the bar a quantum model is read against. Energy is a range from assumed powers, not a measurement: a quantum run is charged 10-25 kW for the seconds it holds the QPU (time share: the system's whole power for the seconds a run holds the QPU), and every classical second 10-50 W (10-25 kW: wall-plug power of superconducting systems (dilution refrigerators 10-25 kW continuous) as cited in arXiv 2605.09580; 10-50 W: one CPU core, assumed).

| row | test accuracy | time | energy, kWh | money |
|---|---|---|---|---|
| classical: logistic | 0.771 | 0.09 s CPU | 2.5e-07-1.2e-06 | - |
| classical: logistic_quad | 0.750 | 0.09 s CPU | 2.5e-07-1.2e-06 | - |
| classical: mlp32 | 0.771 | 0.48 s CPU | 1.3e-06-6.6e-06 | - |
| classical: knn5 | 0.729 | 0.00 s CPU | 1.7e-09-8.4e-09 | - |
| quantum, batch: psfai:template | 0.823 (iteration 200) | 943.9 s holding the QPU | 2.62-6.56 | $1510.24 |
| quantum, session: psfai:template | 0.823 (iteration 200) | 971.2 s holding the QPU | 2.70-6.74 | $1553.95 |
| quantum, batch: qiskit:2:target:template | 0.740 (iteration 200) | 968.0 s holding the QPU | 2.69-6.72 | $1548.73 |
| quantum, session: qiskit:2:target:template | 0.740 (iteration 200) | 988.8 s holding the QPU | 2.75-6.87 | $1582.04 |

The least energy any quantum row is estimated at is 395,037 times the most any classical model is; the best classical accuracy is 0.771 (logistic).

## 3. The trajectory

iteration: accuracy / margin (dollars spent so far, batch / session)

| arm | evaluations |
|---|---|
| psfai:template | 0: 0.344 / -0.151 ($0.0 / $0.0); 20: 0.635 / 0.064 ($151.0 / $155.3); 40: 0.656 / 0.234 ($302.0 / $310.6); 60: 0.667 / 0.273 ($453.1 / $466.0); 80: 0.740 / 0.299 ($604.1 / $621.4); 100: 0.760 / 0.293 ($755.1 / $776.7); 120: 0.719 / 0.300 ($906.1 / $932.2); 140: 0.802 / 0.314 ($1057.2 / $1087.8); 160: 0.781 / 0.324 ($1208.2 / $1243.1); 180: 0.771 / 0.310 ($1359.2 / $1398.5); 200: 0.823 / 0.311 ($1510.2 / $1554.0) |
| qiskit:2:target:template | 0: 0.302 / -0.130 ($0.0 / $0.0); 20: 0.740 / 0.070 ($154.9 / $158.2); 40: 0.750 / 0.108 ($309.7 / $316.4); 60: 0.646 / 0.213 ($464.6 / $474.6); 80: 0.719 / 0.233 ($619.5 / $632.9); 100: 0.708 / 0.223 ($774.4 / $790.9); 120: 0.635 / 0.213 ($929.2 / $949.1); 140: 0.740 / 0.248 ($1084.1 / $1107.3); 160: 0.667 / 0.228 ($1239.0 / $1265.6); 180: 0.708 / 0.236 ($1393.9 / $1423.9); 200: 0.740 / 0.238 ($1548.7 / $1582.0) |

## 4. Secondary: the cost of compiling

Reference qiskit:2:target:template: 14.49 s per loop.

| arm | version | circuits | compile s | per circuit ms | tier | classical s per loop | templates built / not available | 2q gates | duration us |
|---|---|---|---|---|---|---|---|---|---|
| psfai:template | psf_compile 2026-10-15.c61, psf_ai_compile 2026-10-15.a22 | 6928 | 21.50 | 3.10 | 3x | 27.32 | 1 / 0 | 120.0 | 8.71 |
| qiskit:2:target:template | 2.5.2 | 6928 | 14.49 | 2.09 | 1x | 20.82 | 1 / 0 | 158.0 | 18.11 |

## Checks

- psfai:template: structural failures 0, operations on failed elements 0, equivalence 3 of 3 checked
- qiskit:2:target:template: structural failures 0, operations on failed elements 0, equivalence 3 of 3 checked
