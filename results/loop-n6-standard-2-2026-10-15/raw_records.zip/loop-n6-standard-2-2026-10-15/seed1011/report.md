# TOQB loop standard run 2 n6 L8 (seed 1011): for the same money, which compiler returns the best model?

Device fake:FakeFez; front end qiskit; task {"n": 6, "layers": 8, "enc": 1.5707963267948966, "teacher_seed": 4, "teacher_gap": 0.2, "n_train": 64, "n_test": 48}; optimizer {"name": "SPSA", "iterations": 200, "batch": 16, "a": 10.0, "c": 0.4, "A": 2, "init": 0.5, "loop_seed": 1011}; evaluation {"shots": 400, "shot_seed": 20261015, "every": 20, "target_accuracy": 0.7}.

Price: 0.00027 s per shot + 0.036 s per circuit + the circuit's duration per shot, at $1.60 per QPU second (rate: PSF-Zero TIME1 / FRAC1 on ibm_fez (2026-10-14); price: IBM Pay-As-You-Go, 'starts at $96 USD / minute', billed per second (ibm.com/quantum/pricing, 2026-10-15)).

Budget: batch $1626.17, session $1663.50 (what the reference arm qiskit:2:target:template spent on the whole training, plus 5%).

## 1. The result for the money

Accuracy / margin on the test set at the last evaluation within the budget (iteration in brackets); dollars to reach accuracy 0.7; noiseless accuracy of the final angles.

| arm | valid | batch: within budget | session: within budget | $ to target (batch / session) | spent on the whole training (batch / session) | final noiseless accuracy |
|---|---|---|---|---|---|---|
| psfai:template | yes | 0.688 / 0.093 (200) | 0.688 / 0.093 (200) | $453.07 / $466.37 | $1510.24 / $1553.98 | 0.750 |
| qiskit:2:target:template | yes | 0.708 / 0.135 (200) | 0.708 / 0.135 (200) | $1084.11 / $1108.80 | $1548.73 / $1584.29 | 0.729 |

## 2. Reference: classical models, and energy

Not a contest: TOQB compares compilers. The classical models (`toqb.classical`, numpy only, one fixed configuration each) are trained on the same training points and scored on the same test points, as the bar a quantum model is read against. Energy is a range from assumed powers, not a measurement: a quantum run is charged 10-25 kW for the seconds it holds the QPU (time share: the system's whole power for the seconds a run holds the QPU), and every classical second 10-50 W (10-25 kW: wall-plug power of superconducting systems (dilution refrigerators 10-25 kW continuous) as cited in arXiv 2605.09580; 10-50 W: one CPU core, assumed).

| row | test accuracy | time | energy, kWh | money |
|---|---|---|---|---|
| classical: logistic | 0.771 | 0.08 s CPU | 2.1e-07-1e-06 | - |
| classical: logistic_quad | 0.750 | 0.10 s CPU | 2.7e-07-1.3e-06 | - |
| classical: mlp32 | 0.771 | 0.48 s CPU | 1.3e-06-6.6e-06 | - |
| classical: knn5 | 0.729 | 0.00 s CPU | 1.4e-09-7.1e-09 | - |
| quantum, batch: psfai:template | 0.688 (iteration 200) | 943.9 s holding the QPU | 2.62-6.56 | $1510.24 |
| quantum, session: psfai:template | 0.688 (iteration 200) | 971.2 s holding the QPU | 2.70-6.75 | $1553.98 |
| quantum, batch: qiskit:2:target:template | 0.708 (iteration 200) | 968.0 s holding the QPU | 2.69-6.72 | $1548.73 |
| quantum, session: qiskit:2:target:template | 0.708 (iteration 200) | 990.2 s holding the QPU | 2.75-6.88 | $1584.29 |

The least energy any quantum row is estimated at is 397,128 times the most any classical model is; the best classical accuracy is 0.771 (logistic).

## 3. The trajectory

iteration: accuracy / margin (dollars spent so far, batch / session)

| arm | evaluations |
|---|---|
| psfai:template | 0: 0.312 / -0.145 ($0.0 / $0.0); 20: 0.656 / 0.083 ($151.0 / $155.3); 40: 0.635 / 0.100 ($302.0 / $311.0); 60: 0.750 / 0.095 ($453.1 / $466.4); 80: 0.677 / 0.100 ($604.1 / $621.7); 100: 0.698 / 0.095 ($755.1 / $777.0); 120: 0.781 / 0.088 ($906.1 / $932.4); 140: 0.688 / 0.097 ($1057.2 / $1088.0); 160: 0.719 / 0.109 ($1208.2 / $1243.5); 180: 0.698 / 0.093 ($1359.2 / $1398.7); 200: 0.688 / 0.093 ($1510.2 / $1554.0) |
| qiskit:2:target:template | 0: 0.292 / -0.128 ($0.0 / $0.0); 20: 0.625 / 0.044 ($154.9 / $158.1); 40: 0.635 / 0.039 ($309.7 / $316.2); 60: 0.656 / 0.055 ($464.6 / $474.5); 80: 0.562 / 0.035 ($619.5 / $633.2); 100: 0.667 / 0.057 ($774.4 / $791.8); 120: 0.604 / 0.047 ($929.2 / $950.2); 140: 0.708 / 0.067 ($1084.1 / $1108.8); 160: 0.792 / 0.104 ($1239.0 / $1267.3); 180: 0.729 / 0.121 ($1393.9 / $1425.7); 200: 0.708 / 0.135 ($1548.7 / $1584.3) |

## 4. Secondary: the cost of compiling

Reference qiskit:2:target:template: 15.46 s per loop.

| arm | version | circuits | compile s | per circuit ms | tier | classical s per loop | templates built / not available | 2q gates | duration us |
|---|---|---|---|---|---|---|---|---|---|
| psfai:template | psf_compile 2026-10-15.c61, psf_ai_compile 2026-10-15.a22 | 6928 | 21.45 | 3.09 | 3x | 27.33 | 1 / 0 | 120.0 | 8.71 |
| qiskit:2:target:template | 2.5.2 | 6928 | 15.46 | 2.23 | 1x | 22.22 | 1 / 0 | 158.0 | 18.11 |

## Checks

- psfai:template: structural failures 0, operations on failed elements 0, equivalence 3 of 3 checked
- qiskit:2:target:template: structural failures 0, operations on failed elements 0, equivalence 3 of 3 checked
