# TOQB loop standard run 2 n6 L8 (seed 1146): for the same money, which compiler returns the best model?

Device fake:FakeFez; front end qiskit; task {"n": 6, "layers": 8, "enc": 1.5707963267948966, "teacher_seed": 4, "teacher_gap": 0.2, "n_train": 64, "n_test": 48}; optimizer {"name": "SPSA", "iterations": 200, "batch": 16, "a": 10.0, "c": 0.4, "A": 2, "init": 0.5, "loop_seed": 1146}; evaluation {"shots": 400, "shot_seed": 20261015, "every": 20, "target_accuracy": 0.7}.

Price: 0.00027 s per shot + 0.036 s per circuit + the circuit's duration per shot, at $1.60 per QPU second (rate: PSF-Zero TIME1 / FRAC1 on ibm_fez (2026-10-14); price: IBM Pay-As-You-Go, 'starts at $96 USD / minute', billed per second (ibm.com/quantum/pricing, 2026-10-15)).

Budget: batch $1626.17, session $1660.60 (what the reference arm qiskit:2:target:template spent on the whole training, plus 5%).

## 1. The result for the money

Accuracy / margin on the test set at the last evaluation within the budget (iteration in brackets); dollars to reach accuracy 0.7; noiseless accuracy of the final angles.

| arm | valid | batch: within budget | session: within budget | $ to target (batch / session) | spent on the whole training (batch / session) | final noiseless accuracy |
|---|---|---|---|---|---|---|
| psfai:template | yes | 0.708 / 0.322 (200) | 0.708 / 0.322 (200) | $151.02 / $154.90 | $1510.24 / $1553.07 | 0.750 |
| qiskit:2:target:template | yes | 0.688 / 0.249 (200) | 0.688 / 0.249 (200) | $309.75 / $316.00 | $1548.73 / $1581.52 | 0.688 |

## 2. Reference: classical models, and energy

Not a contest: TOQB compares compilers. The classical models (`toqb.classical`, numpy only, one fixed configuration each) are trained on the same training points and scored on the same test points, as the bar a quantum model is read against. Energy is a range from assumed powers, not a measurement: a quantum run is charged 10-25 kW for the seconds it holds the QPU (time share: the system's whole power for the seconds a run holds the QPU), and every classical second 10-50 W (10-25 kW: wall-plug power of superconducting systems (dilution refrigerators 10-25 kW continuous) as cited in arXiv 2605.09580; 10-50 W: one CPU core, assumed).

| row | test accuracy | time | energy, kWh | money |
|---|---|---|---|---|
| classical: logistic | 0.771 | 0.09 s CPU | 2.5e-07-1.2e-06 | - |
| classical: logistic_quad | 0.750 | 0.10 s CPU | 2.8e-07-1.4e-06 | - |
| classical: mlp32 | 0.771 | 0.47 s CPU | 1.3e-06-6.5e-06 | - |
| classical: knn5 | 0.729 | 0.00 s CPU | 1.1e-09-5.5e-09 | - |
| quantum, batch: psfai:template | 0.708 (iteration 200) | 943.9 s holding the QPU | 2.62-6.56 | $1510.24 |
| quantum, session: psfai:template | 0.708 (iteration 200) | 970.7 s holding the QPU | 2.70-6.74 | $1553.07 |
| quantum, batch: qiskit:2:target:template | 0.688 (iteration 200) | 968.0 s holding the QPU | 2.69-6.72 | $1548.73 |
| quantum, session: qiskit:2:target:template | 0.688 (iteration 200) | 988.5 s holding the QPU | 2.75-6.86 | $1581.52 |

The least energy any quantum row is estimated at is 402,695 times the most any classical model is; the best classical accuracy is 0.771 (logistic).

## 3. The trajectory

iteration: accuracy / margin (dollars spent so far, batch / session)

| arm | evaluations |
|---|---|
| psfai:template | 0: 0.312 / -0.147 ($0.0 / $0.0); 20: 0.729 / 0.276 ($151.0 / $154.9); 40: 0.708 / 0.259 ($302.0 / $310.4); 60: 0.771 / 0.291 ($453.1 / $465.7); 80: 0.740 / 0.310 ($604.1 / $621.3); 100: 0.688 / 0.292 ($755.1 / $776.7); 120: 0.604 / 0.287 ($906.1 / $931.9); 140: 0.667 / 0.292 ($1057.2 / $1087.4); 160: 0.708 / 0.313 ($1208.2 / $1242.8); 180: 0.667 / 0.299 ($1359.2 / $1397.8); 200: 0.708 / 0.322 ($1510.2 / $1553.1) |
| qiskit:2:target:template | 0: 0.312 / -0.130 ($0.0 / $0.0); 20: 0.625 / 0.161 ($154.9 / $158.1); 40: 0.708 / 0.203 ($309.7 / $316.0); 60: 0.677 / 0.204 ($464.6 / $474.3); 80: 0.646 / 0.216 ($619.5 / $632.6); 100: 0.740 / 0.226 ($774.4 / $790.9); 120: 0.781 / 0.244 ($929.2 / $949.0); 140: 0.729 / 0.247 ($1084.1 / $1107.4); 160: 0.688 / 0.244 ($1239.0 / $1265.4); 180: 0.698 / 0.249 ($1393.9 / $1423.5); 200: 0.688 / 0.249 ($1548.7 / $1581.5) |

## 4. Secondary: the cost of compiling

Reference qiskit:2:target:template: 14.17 s per loop.

| arm | version | circuits | compile s | per circuit ms | tier | classical s per loop | templates built / not available | 2q gates | duration us |
|---|---|---|---|---|---|---|---|---|---|
| psfai:template | psf_compile 2026-10-15.c61, psf_ai_compile 2026-10-15.a22 | 6928 | 21.20 | 3.06 | 3x | 26.76 | 1 / 0 | 120.0 | 8.71 |
| qiskit:2:target:template | 2.5.2 | 6928 | 14.17 | 2.04 | 1x | 20.49 | 1 / 0 | 158.0 | 18.11 |

## Checks

- psfai:template: structural failures 0, operations on failed elements 0, equivalence 3 of 3 checked
- qiskit:2:target:template: structural failures 0, operations on failed elements 0, equivalence 3 of 3 checked
