# TOQB loop standard run 2 n6 L8 (seed 1192): for the same money, which compiler returns the best model?

Device fake:FakeFez; front end qiskit; task {"n": 6, "layers": 8, "enc": 1.5707963267948966, "teacher_seed": 4, "teacher_gap": 0.2, "n_train": 64, "n_test": 48}; optimizer {"name": "SPSA", "iterations": 200, "batch": 16, "a": 10.0, "c": 0.4, "A": 2, "init": 0.5, "loop_seed": 1192}; evaluation {"shots": 400, "shot_seed": 20261015, "every": 20, "target_accuracy": 0.7}.

Price: 0.00027 s per shot + 0.036 s per circuit + the circuit's duration per shot, at $1.60 per QPU second (rate: PSF-Zero TIME1 / FRAC1 on ibm_fez (2026-10-14); price: IBM Pay-As-You-Go, 'starts at $96 USD / minute', billed per second (ibm.com/quantum/pricing, 2026-10-15)).

Budget: batch $1626.17, session $1662.63 (what the reference arm qiskit:2:target:template spent on the whole training, plus 5%).

## 1. The result for the money

Accuracy / margin on the test set at the last evaluation within the budget (iteration in brackets); dollars to reach accuracy 0.7; noiseless accuracy of the final angles.

| arm | valid | batch: within budget | session: within budget | $ to target (batch / session) | spent on the whole training (batch / session) | final noiseless accuracy |
|---|---|---|---|---|---|---|
| psfai:template | yes | 0.646 / 0.259 (200) | 0.646 / 0.259 (200) | $755.12 / $776.14 | $1510.24 / $1552.63 | 0.646 |
| qiskit:2:target:template | yes | 0.625 / 0.051 (200) | 0.625 / 0.051 (200) | not reached / not reached | $1548.73 / $1583.46 | 0.708 |

## 2. Reference: classical models, and energy

Not a contest: TOQB compares compilers. The classical models (`toqb.classical`, numpy only, one fixed configuration each) are trained on the same training points and scored on the same test points, as the bar a quantum model is read against. Energy is a range from assumed powers, not a measurement: a quantum run is charged 10-25 kW for the seconds it holds the QPU (time share: the system's whole power for the seconds a run holds the QPU), and every classical second 10-50 W (10-25 kW: wall-plug power of superconducting systems (dilution refrigerators 10-25 kW continuous) as cited in arXiv 2605.09580; 10-50 W: one CPU core, assumed).

| row | test accuracy | time | energy, kWh | money |
|---|---|---|---|---|
| classical: logistic | 0.771 | 0.04 s CPU | 1.2e-07-6.2e-07 | - |
| classical: logistic_quad | 0.750 | 0.05 s CPU | 1.5e-07-7.5e-07 | - |
| classical: mlp32 | 0.771 | 0.30 s CPU | 8.3e-07-4.2e-06 | - |
| classical: knn5 | 0.729 | 0.00 s CPU | 1e-09-5.1e-09 | - |
| quantum, batch: psfai:template | 0.646 (iteration 200) | 943.9 s holding the QPU | 2.62-6.56 | $1510.24 |
| quantum, session: psfai:template | 0.646 (iteration 200) | 970.4 s holding the QPU | 2.70-6.74 | $1552.63 |
| quantum, batch: qiskit:2:target:template | 0.625 (iteration 200) | 968.0 s holding the QPU | 2.69-6.72 | $1548.73 |
| quantum, session: qiskit:2:target:template | 0.625 (iteration 200) | 989.7 s holding the QPU | 2.75-6.87 | $1583.46 |

The least energy any quantum row is estimated at is 631,633 times the most any classical model is; the best classical accuracy is 0.771 (logistic).

## 3. The trajectory

iteration: accuracy / margin (dollars spent so far, batch / session)

| arm | evaluations |
|---|---|
| psfai:template | 0: 0.292 / -0.133 ($0.0 / $0.0); 20: 0.635 / 0.007 ($151.0 / $155.0); 40: 0.604 / 0.011 ($302.0 / $310.3); 60: 0.594 / 0.044 ($453.1 / $465.5); 80: 0.688 / 0.112 ($604.1 / $620.7); 100: 0.750 / 0.183 ($755.1 / $776.1); 120: 0.833 / 0.292 ($906.1 / $931.3); 140: 0.719 / 0.264 ($1057.2 / $1086.8); 160: 0.708 / 0.274 ($1208.2 / $1242.1); 180: 0.729 / 0.261 ($1359.2 / $1397.5); 200: 0.646 / 0.259 ($1510.2 / $1552.6) |
| qiskit:2:target:template | 0: 0.354 / -0.107 ($0.0 / $0.0); 20: 0.552 / 0.001 ($154.9 / $157.9); 40: 0.417 / -0.014 ($309.7 / $316.2); 60: 0.458 / -0.008 ($464.6 / $474.6); 80: 0.469 / -0.002 ($619.5 / $632.8); 100: 0.562 / 0.019 ($774.4 / $791.2); 120: 0.656 / 0.039 ($929.2 / $949.7); 140: 0.583 / 0.026 ($1084.1 / $1108.1); 160: 0.646 / 0.049 ($1239.0 / $1266.8); 180: 0.688 / 0.053 ($1393.9 / $1425.3); 200: 0.625 / 0.051 ($1548.7 / $1583.5) |

## 4. Secondary: the cost of compiling

Reference qiskit:2:target:template: 15.32 s per loop.

| arm | version | circuits | compile s | per circuit ms | tier | classical s per loop | templates built / not available | 2q gates | duration us |
|---|---|---|---|---|---|---|---|---|---|
| psfai:template | psf_compile 2026-10-15.c61, psf_ai_compile 2026-10-15.a22 | 6928 | 20.90 | 3.02 | 3x | 26.49 | 1 / 0 | 120.0 | 8.71 |
| qiskit:2:target:template | 2.5.2 | 6928 | 15.32 | 2.21 | 1x | 21.70 | 1 / 0 | 158.0 | 18.11 |

## Checks

- psfai:template: structural failures 0, operations on failed elements 0, equivalence 3 of 3 checked
- qiskit:2:target:template: structural failures 0, operations on failed elements 0, equivalence 3 of 3 checked
