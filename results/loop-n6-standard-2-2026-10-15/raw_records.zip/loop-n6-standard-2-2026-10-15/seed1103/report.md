# TOQB loop standard run 2 n6 L8 (seed 1103): for the same money, which compiler returns the best model?

Device fake:FakeFez; front end qiskit; task {"n": 6, "layers": 8, "enc": 1.5707963267948966, "teacher_seed": 4, "teacher_gap": 0.2, "n_train": 64, "n_test": 48}; optimizer {"name": "SPSA", "iterations": 200, "batch": 16, "a": 10.0, "c": 0.4, "A": 2, "init": 0.5, "loop_seed": 1103}; evaluation {"shots": 400, "shot_seed": 20261015, "every": 20, "target_accuracy": 0.7}.

Price: 0.00027 s per shot + 0.036 s per circuit + the circuit's duration per shot, at $1.60 per QPU second (rate: PSF-Zero TIME1 / FRAC1 on ibm_fez (2026-10-14); price: IBM Pay-As-You-Go, 'starts at $96 USD / minute', billed per second (ibm.com/quantum/pricing, 2026-10-15)).

Budget: batch $1626.17, session $1660.63 (what the reference arm qiskit:2:target:template spent on the whole training, plus 5%).

## 1. The result for the money

Accuracy / margin on the test set at the last evaluation within the budget (iteration in brackets); dollars to reach accuracy 0.7; noiseless accuracy of the final angles.

| arm | valid | batch: within budget | session: within budget | $ to target (batch / session) | spent on the whole training (batch / session) | final noiseless accuracy |
|---|---|---|---|---|---|---|
| psfai:template | yes | 0.552 / 0.012 (200) | 0.552 / 0.012 (200) | not reached / not reached | $1510.24 / $1554.06 | 0.542 |
| qiskit:2:target:template | yes | 0.708 / 0.053 (200) | 0.708 / 0.053 (200) | $1393.86 / $1423.47 | $1548.73 / $1581.56 | 0.729 |

## 2. Reference: classical models, and energy

Not a contest: TOQB compares compilers. The classical models (`toqb.classical`, numpy only, one fixed configuration each) are trained on the same training points and scored on the same test points, as the bar a quantum model is read against. Energy is a range from assumed powers, not a measurement: a quantum run is charged 10-25 kW for the seconds it holds the QPU (time share: the system's whole power for the seconds a run holds the QPU), and every classical second 10-50 W (10-25 kW: wall-plug power of superconducting systems (dilution refrigerators 10-25 kW continuous) as cited in arXiv 2605.09580; 10-50 W: one CPU core, assumed).

| row | test accuracy | time | energy, kWh | money |
|---|---|---|---|---|
| classical: logistic | 0.771 | 0.07 s CPU | 1.9e-07-9.5e-07 | - |
| classical: logistic_quad | 0.750 | 0.08 s CPU | 2.3e-07-1.2e-06 | - |
| classical: mlp32 | 0.771 | 0.42 s CPU | 1.2e-06-5.8e-06 | - |
| classical: knn5 | 0.729 | 0.00 s CPU | 1.8e-09-8.8e-09 | - |
| quantum, batch: psfai:template | 0.552 (iteration 200) | 943.9 s holding the QPU | 2.62-6.56 | $1510.24 |
| quantum, session: psfai:template | 0.552 (iteration 200) | 971.3 s holding the QPU | 2.70-6.75 | $1554.06 |
| quantum, batch: qiskit:2:target:template | 0.708 (iteration 200) | 968.0 s holding the QPU | 2.69-6.72 | $1548.73 |
| quantum, session: qiskit:2:target:template | 0.708 (iteration 200) | 988.5 s holding the QPU | 2.75-6.86 | $1581.56 |

The least energy any quantum row is estimated at is 454,608 times the most any classical model is; the best classical accuracy is 0.771 (logistic).

## 3. The trajectory

iteration: accuracy / margin (dollars spent so far, batch / session)

| arm | evaluations |
|---|---|
| psfai:template | 0: 0.208 / -0.194 ($0.0 / $0.0); 20: 0.385 / -0.031 ($151.0 / $155.4); 40: 0.635 / 0.025 ($302.0 / $310.7); 60: 0.552 / 0.000 ($453.1 / $466.0); 80: 0.625 / 0.028 ($604.1 / $621.5); 100: 0.552 / 0.031 ($755.1 / $776.8); 120: 0.594 / 0.018 ($906.1 / $932.3); 140: 0.531 / 0.006 ($1057.2 / $1087.8); 160: 0.469 / 0.011 ($1208.2 / $1243.4); 180: 0.562 / 0.033 ($1359.2 / $1398.6); 200: 0.552 / 0.012 ($1510.2 / $1554.1) |
| qiskit:2:target:template | 0: 0.281 / -0.168 ($0.0 / $0.1); 20: 0.354 / -0.028 ($154.9 / $157.8); 40: 0.521 / -0.000 ($309.7 / $315.9); 60: 0.635 / 0.024 ($464.6 / $474.0); 80: 0.521 / 0.007 ($619.5 / $632.4); 100: 0.542 / 0.017 ($774.4 / $790.4); 120: 0.635 / 0.041 ($929.2 / $948.6); 140: 0.635 / 0.027 ($1084.1 / $1107.1); 160: 0.646 / 0.044 ($1239.0 / $1265.4); 180: 0.750 / 0.058 ($1393.9 / $1423.5); 200: 0.708 / 0.053 ($1548.7 / $1581.6) |

## 4. Secondary: the cost of compiling

Reference qiskit:2:target:template: 14.22 s per loop.

| arm | version | circuits | compile s | per circuit ms | tier | classical s per loop | templates built / not available | 2q gates | duration us |
|---|---|---|---|---|---|---|---|---|---|
| psfai:template | psf_compile 2026-10-15.c61, psf_ai_compile 2026-10-15.a22 | 6928 | 21.66 | 3.13 | 3x | 27.38 | 1 / 0 | 120.0 | 8.71 |
| qiskit:2:target:template | 2.5.2 | 6928 | 14.22 | 2.05 | 1x | 20.52 | 1 / 0 | 158.0 | 18.11 |

## Checks

- psfai:template: structural failures 0, operations on failed elements 0, equivalence 3 of 3 checked
- qiskit:2:target:template: structural failures 0, operations on failed elements 0, equivalence 3 of 3 checked
