# TOQB loop standard run 2 n6 L8 (seed 1052): for the same money, which compiler returns the best model?

Device fake:FakeFez; front end qiskit; task {"n": 6, "layers": 8, "enc": 1.5707963267948966, "teacher_seed": 4, "teacher_gap": 0.2, "n_train": 64, "n_test": 48}; optimizer {"name": "SPSA", "iterations": 200, "batch": 16, "a": 10.0, "c": 0.4, "A": 2, "init": 0.5, "loop_seed": 1052}; evaluation {"shots": 400, "shot_seed": 20261015, "every": 20, "target_accuracy": 0.7}.

Price: 0.00027 s per shot + 0.036 s per circuit + the circuit's duration per shot, at $1.60 per QPU second (rate: PSF-Zero TIME1 / FRAC1 on ibm_fez (2026-10-14); price: IBM Pay-As-You-Go, 'starts at $96 USD / minute', billed per second (ibm.com/quantum/pricing, 2026-10-15)).

Budget: batch $1626.17, session $1661.46 (what the reference arm qiskit:2:target:template spent on the whole training, plus 5%).

## 1. The result for the money

Accuracy / margin on the test set at the last evaluation within the budget (iteration in brackets); dollars to reach accuracy 0.7; noiseless accuracy of the final angles.

| arm | valid | batch: within budget | session: within budget | $ to target (batch / session) | spent on the whole training (batch / session) | final noiseless accuracy |
|---|---|---|---|---|---|---|
| psfai:template | yes | 0.635 / 0.089 (200) | 0.635 / 0.089 (200) | $755.12 / $776.24 | $1510.24 / $1552.60 | 0.625 |
| qiskit:2:target:template | yes | 0.896 / 0.166 (200) | 0.896 / 0.166 (200) | $1238.98 / $1265.91 | $1548.73 / $1582.34 | 0.854 |

## 2. Reference: classical models, and energy

Not a contest: TOQB compares compilers. The classical models (`toqb.classical`, numpy only, one fixed configuration each) are trained on the same training points and scored on the same test points, as the bar a quantum model is read against. Energy is a range from assumed powers, not a measurement: a quantum run is charged 10-25 kW for the seconds it holds the QPU (time share: the system's whole power for the seconds a run holds the QPU), and every classical second 10-50 W (10-25 kW: wall-plug power of superconducting systems (dilution refrigerators 10-25 kW continuous) as cited in arXiv 2605.09580; 10-50 W: one CPU core, assumed).

| row | test accuracy | time | energy, kWh | money |
|---|---|---|---|---|
| classical: logistic | 0.771 | 0.09 s CPU | 2.6e-07-1.3e-06 | - |
| classical: logistic_quad | 0.750 | 0.06 s CPU | 1.8e-07-9e-07 | - |
| classical: mlp32 | 0.771 | 0.45 s CPU | 1.2e-06-6.2e-06 | - |
| classical: knn5 | 0.729 | 0.00 s CPU | 1.4e-09-6.8e-09 | - |
| quantum, batch: psfai:template | 0.635 (iteration 200) | 943.9 s holding the QPU | 2.62-6.56 | $1510.24 |
| quantum, session: psfai:template | 0.635 (iteration 200) | 970.4 s holding the QPU | 2.70-6.74 | $1552.60 |
| quantum, batch: qiskit:2:target:template | 0.896 (iteration 200) | 968.0 s holding the QPU | 2.69-6.72 | $1548.73 |
| quantum, session: qiskit:2:target:template | 0.896 (iteration 200) | 989.0 s holding the QPU | 2.75-6.87 | $1582.34 |

The least energy any quantum row is estimated at is 421,825 times the most any classical model is; the best classical accuracy is 0.771 (logistic).

## 3. The trajectory

iteration: accuracy / margin (dollars spent so far, batch / session)

| arm | evaluations |
|---|---|
| psfai:template | 0: 0.323 / -0.173 ($0.0 / $0.0); 20: 0.344 / -0.021 ($151.0 / $155.1); 40: 0.510 / 0.011 ($302.0 / $310.3); 60: 0.427 / 0.004 ($453.1 / $465.6); 80: 0.479 / 0.040 ($604.1 / $620.9); 100: 0.729 / 0.094 ($755.1 / $776.2); 120: 0.698 / 0.070 ($906.1 / $931.7); 140: 0.750 / 0.091 ($1057.2 / $1086.9); 160: 0.792 / 0.115 ($1208.2 / $1242.2); 180: 0.646 / 0.100 ($1359.2 / $1397.6); 200: 0.635 / 0.089 ($1510.2 / $1552.6) |
| qiskit:2:target:template | 0: 0.344 / -0.143 ($0.0 / $0.1); 20: 0.406 / -0.024 ($154.9 / $158.0); 40: 0.469 / -0.009 ($309.7 / $316.3); 60: 0.604 / 0.011 ($464.6 / $474.3); 80: 0.562 / 0.025 ($619.5 / $632.7); 100: 0.562 / 0.024 ($774.4 / $790.9); 120: 0.615 / 0.061 ($929.2 / $949.3); 140: 0.615 / 0.069 ($1084.1 / $1107.6); 160: 0.750 / 0.110 ($1239.0 / $1265.9); 180: 0.875 / 0.142 ($1393.9 / $1424.2); 200: 0.896 / 0.166 ($1548.7 / $1582.3) |

## 4. Secondary: the cost of compiling

Reference qiskit:2:target:template: 14.71 s per loop.

| arm | version | circuits | compile s | per circuit ms | tier | classical s per loop | templates built / not available | 2q gates | duration us |
|---|---|---|---|---|---|---|---|---|---|
| psfai:template | psf_compile 2026-10-15.c61, psf_ai_compile 2026-10-15.a22 | 6928 | 20.93 | 3.02 | 3x | 26.47 | 1 / 0 | 120.0 | 8.71 |
| qiskit:2:target:template | 2.5.2 | 6928 | 14.71 | 2.12 | 1x | 21.01 | 1 / 0 | 158.0 | 18.11 |

## Checks

- psfai:template: structural failures 0, operations on failed elements 0, equivalence 3 of 3 checked
- qiskit:2:target:template: structural failures 0, operations on failed elements 0, equivalence 3 of 3 checked
