# TOQB loop standard run 2 n6 L8 (seed 1044): for the same money, which compiler returns the best model?

Device fake:FakeFez; front end qiskit; task {"n": 6, "layers": 8, "enc": 1.5707963267948966, "teacher_seed": 4, "teacher_gap": 0.2, "n_train": 64, "n_test": 48}; optimizer {"name": "SPSA", "iterations": 200, "batch": 16, "a": 10.0, "c": 0.4, "A": 2, "init": 0.5, "loop_seed": 1044}; evaluation {"shots": 400, "shot_seed": 20261015, "every": 20, "target_accuracy": 0.7}.

Price: 0.00027 s per shot + 0.036 s per circuit + the circuit's duration per shot, at $1.60 per QPU second (rate: PSF-Zero TIME1 / FRAC1 on ibm_fez (2026-10-14); price: IBM Pay-As-You-Go, 'starts at $96 USD / minute', billed per second (ibm.com/quantum/pricing, 2026-10-15)).

Budget: batch $1626.17, session $1661.18 (what the reference arm qiskit:2:target:template spent on the whole training, plus 5%).

## 1. The result for the money

Accuracy / margin on the test set at the last evaluation within the budget (iteration in brackets); dollars to reach accuracy 0.7; noiseless accuracy of the final angles.

| arm | valid | batch: within budget | session: within budget | $ to target (batch / session) | spent on the whole training (batch / session) | final noiseless accuracy |
|---|---|---|---|---|---|---|
| psfai:template | yes | 0.729 / 0.120 (200) | 0.729 / 0.120 (200) | $1208.20 / $1242.51 | $1510.24 / $1553.00 | 0.667 |
| qiskit:2:target:template | yes | 0.708 / 0.112 (200) | 0.708 / 0.112 (200) | $929.24 / $949.59 | $1548.73 / $1582.08 | 0.729 |

## 2. Reference: classical models, and energy

Not a contest: TOQB compares compilers. The classical models (`toqb.classical`, numpy only, one fixed configuration each) are trained on the same training points and scored on the same test points, as the bar a quantum model is read against. Energy is a range from assumed powers, not a measurement: a quantum run is charged 10-25 kW for the seconds it holds the QPU (time share: the system's whole power for the seconds a run holds the QPU), and every classical second 10-50 W (10-25 kW: wall-plug power of superconducting systems (dilution refrigerators 10-25 kW continuous) as cited in arXiv 2605.09580; 10-50 W: one CPU core, assumed).

| row | test accuracy | time | energy, kWh | money |
|---|---|---|---|---|
| classical: logistic | 0.771 | 0.07 s CPU | 1.8e-07-9.2e-07 | - |
| classical: logistic_quad | 0.750 | 0.09 s CPU | 2.5e-07-1.3e-06 | - |
| classical: mlp32 | 0.771 | 0.49 s CPU | 1.4e-06-6.8e-06 | - |
| classical: knn5 | 0.729 | 0.00 s CPU | 1.6e-09-7.8e-09 | - |
| quantum, batch: psfai:template | 0.729 (iteration 200) | 943.9 s holding the QPU | 2.62-6.56 | $1510.24 |
| quantum, session: psfai:template | 0.729 (iteration 200) | 970.6 s holding the QPU | 2.70-6.74 | $1553.00 |
| quantum, batch: qiskit:2:target:template | 0.708 (iteration 200) | 968.0 s holding the QPU | 2.69-6.72 | $1548.73 |
| quantum, session: qiskit:2:target:template | 0.708 (iteration 200) | 988.8 s holding the QPU | 2.75-6.87 | $1582.08 |

The least energy any quantum row is estimated at is 387,239 times the most any classical model is; the best classical accuracy is 0.771 (logistic).

## 3. The trajectory

iteration: accuracy / margin (dollars spent so far, batch / session)

| arm | evaluations |
|---|---|
| psfai:template | 0: 0.240 / -0.210 ($0.0 / $0.0); 20: 0.552 / 0.007 ($151.0 / $155.2); 40: 0.573 / 0.018 ($302.0 / $310.8); 60: 0.635 / 0.030 ($453.1 / $465.9); 80: 0.604 / 0.028 ($604.1 / $621.3); 100: 0.573 / 0.027 ($755.1 / $776.6); 120: 0.667 / 0.044 ($906.1 / $931.9); 140: 0.583 / 0.067 ($1057.2 / $1087.2); 160: 0.729 / 0.089 ($1208.2 / $1242.5); 180: 0.677 / 0.096 ($1359.2 / $1397.7); 200: 0.729 / 0.120 ($1510.2 / $1553.0) |
| qiskit:2:target:template | 0: 0.250 / -0.177 ($0.0 / $0.0); 20: 0.573 / 0.030 ($154.9 / $158.1); 40: 0.615 / 0.032 ($309.7 / $316.3); 60: 0.688 / 0.042 ($464.6 / $474.6); 80: 0.625 / 0.045 ($619.5 / $633.0); 100: 0.625 / 0.080 ($774.4 / $791.2); 120: 0.812 / 0.110 ($929.2 / $949.6); 140: 0.802 / 0.127 ($1084.1 / $1107.6); 160: 0.708 / 0.113 ($1239.0 / $1265.7); 180: 0.708 / 0.111 ($1393.9 / $1424.0); 200: 0.708 / 0.112 ($1548.7 / $1582.1) |

## 4. Secondary: the cost of compiling

Reference qiskit:2:target:template: 14.45 s per loop.

| arm | version | circuits | compile s | per circuit ms | tier | classical s per loop | templates built / not available | 2q gates | duration us |
|---|---|---|---|---|---|---|---|---|---|
| psfai:template | psf_compile 2026-10-15.c61, psf_ai_compile 2026-10-15.a22 | 6928 | 20.85 | 3.01 | 3x | 26.72 | 1 / 0 | 120.0 | 8.71 |
| qiskit:2:target:template | 2.5.2 | 6928 | 14.45 | 2.08 | 1x | 20.84 | 1 / 0 | 158.0 | 18.11 |

## Checks

- psfai:template: structural failures 0, operations on failed elements 0, equivalence 3 of 3 checked
- qiskit:2:target:template: structural failures 0, operations on failed elements 0, equivalence 3 of 3 checked
