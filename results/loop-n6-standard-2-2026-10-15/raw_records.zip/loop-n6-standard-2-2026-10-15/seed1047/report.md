# TOQB loop standard run 2 n6 L8 (seed 1047): for the same money, which compiler returns the best model?

Device fake:FakeFez; front end qiskit; task {"n": 6, "layers": 8, "enc": 1.5707963267948966, "teacher_seed": 4, "teacher_gap": 0.2, "n_train": 64, "n_test": 48}; optimizer {"name": "SPSA", "iterations": 200, "batch": 16, "a": 10.0, "c": 0.4, "A": 2, "init": 0.5, "loop_seed": 1047}; evaluation {"shots": 400, "shot_seed": 20261015, "every": 20, "target_accuracy": 0.7}.

Price: 0.00027 s per shot + 0.036 s per circuit + the circuit's duration per shot, at $1.60 per QPU second (rate: PSF-Zero TIME1 / FRAC1 on ibm_fez (2026-10-14); price: IBM Pay-As-You-Go, 'starts at $96 USD / minute', billed per second (ibm.com/quantum/pricing, 2026-10-15)).

Budget: batch $1626.17, session $1661.82 (what the reference arm qiskit:2:target:template spent on the whole training, plus 5%).

## 1. The result for the money

Accuracy / margin on the test set at the last evaluation within the budget (iteration in brackets); dollars to reach accuracy 0.7; noiseless accuracy of the final angles.

| arm | valid | batch: within budget | session: within budget | $ to target (batch / session) | spent on the whole training (batch / session) | final noiseless accuracy |
|---|---|---|---|---|---|---|
| psfai:template | yes | 0.854 / 0.340 (200) | 0.854 / 0.340 (200) | $755.12 / $777.73 | $1510.24 / $1554.69 | 0.854 |
| qiskit:2:target:template | yes | 0.698 / 0.114 (200) | 0.698 / 0.114 (200) | $929.24 / $949.69 | $1548.73 / $1582.68 | 0.667 |

## 2. Reference: classical models, and energy

Not a contest: TOQB compares compilers. The classical models (`toqb.classical`, numpy only, one fixed configuration each) are trained on the same training points and scored on the same test points, as the bar a quantum model is read against. Energy is a range from assumed powers, not a measurement: a quantum run is charged 10-25 kW for the seconds it holds the QPU (time share: the system's whole power for the seconds a run holds the QPU), and every classical second 10-50 W (10-25 kW: wall-plug power of superconducting systems (dilution refrigerators 10-25 kW continuous) as cited in arXiv 2605.09580; 10-50 W: one CPU core, assumed).

| row | test accuracy | time | energy, kWh | money |
|---|---|---|---|---|
| classical: logistic | 0.771 | 0.08 s CPU | 2.2e-07-1.1e-06 | - |
| classical: logistic_quad | 0.750 | 0.06 s CPU | 1.8e-07-8.8e-07 | - |
| classical: mlp32 | 0.771 | 0.44 s CPU | 1.2e-06-6e-06 | - |
| classical: knn5 | 0.729 | 0.00 s CPU | 1.6e-09-7.9e-09 | - |
| quantum, batch: psfai:template | 0.854 (iteration 200) | 943.9 s holding the QPU | 2.62-6.56 | $1510.24 |
| quantum, session: psfai:template | 0.854 (iteration 200) | 971.7 s holding the QPU | 2.70-6.75 | $1554.69 |
| quantum, batch: qiskit:2:target:template | 0.698 (iteration 200) | 968.0 s holding the QPU | 2.69-6.72 | $1548.73 |
| quantum, session: qiskit:2:target:template | 0.698 (iteration 200) | 989.2 s holding the QPU | 2.75-6.87 | $1582.68 |

The least energy any quantum row is estimated at is 433,609 times the most any classical model is; the best classical accuracy is 0.771 (logistic).

## 3. The trajectory

iteration: accuracy / margin (dollars spent so far, batch / session)

| arm | evaluations |
|---|---|
| psfai:template | 0: 0.208 / -0.209 ($0.0 / $0.0); 20: 0.615 / 0.073 ($151.0 / $155.5); 40: 0.646 / 0.072 ($302.0 / $311.0); 60: 0.667 / 0.049 ($453.1 / $466.8); 80: 0.656 / 0.095 ($604.1 / $622.2); 100: 0.740 / 0.095 ($755.1 / $777.7); 120: 0.729 / 0.117 ($906.1 / $933.1); 140: 0.750 / 0.190 ($1057.2 / $1088.7); 160: 0.781 / 0.188 ($1208.2 / $1244.0); 180: 0.750 / 0.216 ($1359.2 / $1399.4); 200: 0.854 / 0.340 ($1510.2 / $1554.7) |
| qiskit:2:target:template | 0: 0.229 / -0.175 ($0.0 / $0.0); 20: 0.490 / 0.007 ($154.9 / $158.1); 40: 0.500 / 0.004 ($309.7 / $316.5); 60: 0.510 / 0.006 ($464.6 / $474.9); 80: 0.531 / 0.014 ($619.5 / $633.2); 100: 0.562 / 0.047 ($774.4 / $791.5); 120: 0.708 / 0.078 ($929.2 / $949.7); 140: 0.729 / 0.099 ($1084.1 / $1107.9); 160: 0.708 / 0.101 ($1239.0 / $1266.2); 180: 0.646 / 0.105 ($1393.9 / $1424.4); 200: 0.698 / 0.114 ($1548.7 / $1582.7) |

## 4. Secondary: the cost of compiling

Reference qiskit:2:target:template: 14.85 s per loop.

| arm | version | circuits | compile s | per circuit ms | tier | classical s per loop | templates built / not available | 2q gates | duration us |
|---|---|---|---|---|---|---|---|---|---|
| psfai:template | psf_compile 2026-10-15.c61, psf_ai_compile 2026-10-15.a22 | 6928 | 21.99 | 3.17 | 3x | 27.78 | 1 / 0 | 120.0 | 8.71 |
| qiskit:2:target:template | 2.5.2 | 6928 | 14.85 | 2.14 | 1x | 21.22 | 1 / 0 | 158.0 | 18.11 |

## Checks

- psfai:template: structural failures 0, operations on failed elements 0, equivalence 3 of 3 checked
- qiskit:2:target:template: structural failures 0, operations on failed elements 0, equivalence 3 of 3 checked
