# TOQB loop standard run 2 n6 L8 (seed 1039): for the same money, which compiler returns the best model?

Device fake:FakeFez; front end qiskit; task {"n": 6, "layers": 8, "enc": 1.5707963267948966, "teacher_seed": 4, "teacher_gap": 0.2, "n_train": 64, "n_test": 48}; optimizer {"name": "SPSA", "iterations": 200, "batch": 16, "a": 10.0, "c": 0.4, "A": 2, "init": 0.5, "loop_seed": 1039}; evaluation {"shots": 400, "shot_seed": 20261015, "every": 20, "target_accuracy": 0.7}.

Price: 0.00027 s per shot + 0.036 s per circuit + the circuit's duration per shot, at $1.60 per QPU second (rate: PSF-Zero TIME1 / FRAC1 on ibm_fez (2026-10-14); price: IBM Pay-As-You-Go, 'starts at $96 USD / minute', billed per second (ibm.com/quantum/pricing, 2026-10-15)).

Budget: batch $1626.17, session $1662.26 (what the reference arm qiskit:2:target:template spent on the whole training, plus 5%).

## 1. The result for the money

Accuracy / margin on the test set at the last evaluation within the budget (iteration in brackets); dollars to reach accuracy 0.7; noiseless accuracy of the final angles.

| arm | valid | batch: within budget | session: within budget | $ to target (batch / session) | spent on the whole training (batch / session) | final noiseless accuracy |
|---|---|---|---|---|---|---|
| psfai:template | yes | 0.812 / 0.290 (200) | 0.812 / 0.290 (200) | $302.05 / $310.52 | $1510.24 / $1553.19 | 0.792 |
| qiskit:2:target:template | yes | 0.750 / 0.171 (200) | 0.750 / 0.171 (200) | $1238.98 / $1266.34 | $1548.73 / $1583.11 | 0.708 |

## 2. Reference: classical models, and energy

Not a contest: TOQB compares compilers. The classical models (`toqb.classical`, numpy only, one fixed configuration each) are trained on the same training points and scored on the same test points, as the bar a quantum model is read against. Energy is a range from assumed powers, not a measurement: a quantum run is charged 10-25 kW for the seconds it holds the QPU (time share: the system's whole power for the seconds a run holds the QPU), and every classical second 10-50 W (10-25 kW: wall-plug power of superconducting systems (dilution refrigerators 10-25 kW continuous) as cited in arXiv 2605.09580; 10-50 W: one CPU core, assumed).

| row | test accuracy | time | energy, kWh | money |
|---|---|---|---|---|
| classical: logistic | 0.771 | 0.09 s CPU | 2.4e-07-1.2e-06 | - |
| classical: logistic_quad | 0.750 | 0.09 s CPU | 2.4e-07-1.2e-06 | - |
| classical: mlp32 | 0.771 | 0.40 s CPU | 1.1e-06-5.5e-06 | - |
| classical: knn5 | 0.729 | 0.00 s CPU | 1.7e-09-8.6e-09 | - |
| quantum, batch: psfai:template | 0.812 (iteration 200) | 943.9 s holding the QPU | 2.62-6.56 | $1510.24 |
| quantum, session: psfai:template | 0.812 (iteration 200) | 970.7 s holding the QPU | 2.70-6.74 | $1553.19 |
| quantum, batch: qiskit:2:target:template | 0.750 (iteration 200) | 968.0 s holding the QPU | 2.69-6.72 | $1548.73 |
| quantum, session: qiskit:2:target:template | 0.750 (iteration 200) | 989.4 s holding the QPU | 2.75-6.87 | $1583.11 |

The least energy any quantum row is estimated at is 475,802 times the most any classical model is; the best classical accuracy is 0.771 (logistic).

## 3. The trajectory

iteration: accuracy / margin (dollars spent so far, batch / session)

| arm | evaluations |
|---|---|
| psfai:template | 0: 0.250 / -0.210 ($0.0 / $0.0); 20: 0.615 / 0.141 ($151.0 / $155.2); 40: 0.750 / 0.201 ($302.0 / $310.5); 60: 0.729 / 0.251 ($453.1 / $465.8); 80: 0.667 / 0.260 ($604.1 / $621.1); 100: 0.646 / 0.240 ($755.1 / $776.5); 120: 0.698 / 0.255 ($906.1 / $931.6); 140: 0.771 / 0.291 ($1057.2 / $1086.9); 160: 0.760 / 0.279 ($1208.2 / $1242.3); 180: 0.760 / 0.274 ($1359.2 / $1397.7); 200: 0.812 / 0.290 ($1510.2 / $1553.2) |
| qiskit:2:target:template | 0: 0.260 / -0.176 ($0.0 / $0.0); 20: 0.417 / 0.002 ($154.9 / $158.2); 40: 0.542 / 0.014 ($309.7 / $316.3); 60: 0.542 / 0.038 ($464.6 / $474.7); 80: 0.646 / 0.054 ($619.5 / $633.0); 100: 0.604 / 0.085 ($774.4 / $791.5); 120: 0.625 / 0.136 ($929.2 / $949.7); 140: 0.635 / 0.162 ($1084.1 / $1108.1); 160: 0.729 / 0.185 ($1239.0 / $1266.3); 180: 0.729 / 0.183 ($1393.9 / $1424.7); 200: 0.750 / 0.171 ($1548.7 / $1583.1) |

## 4. Secondary: the cost of compiling

Reference qiskit:2:target:template: 14.95 s per loop.

| arm | version | circuits | compile s | per circuit ms | tier | classical s per loop | templates built / not available | 2q gates | duration us |
|---|---|---|---|---|---|---|---|---|---|
| psfai:template | psf_compile 2026-10-15.c61, psf_ai_compile 2026-10-15.a22 | 6928 | 21.05 | 3.04 | 3x | 26.84 | 1 / 0 | 120.0 | 8.71 |
| qiskit:2:target:template | 2.5.2 | 6928 | 14.95 | 2.15 | 1x | 21.48 | 1 / 0 | 158.0 | 18.11 |

## Checks

- psfai:template: structural failures 0, operations on failed elements 0, equivalence 3 of 3 checked
- qiskit:2:target:template: structural failures 0, operations on failed elements 0, equivalence 3 of 3 checked
