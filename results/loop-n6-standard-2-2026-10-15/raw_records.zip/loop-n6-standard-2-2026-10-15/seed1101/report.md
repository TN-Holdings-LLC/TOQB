# TOQB loop standard run 2 n6 L8 (seed 1101): for the same money, which compiler returns the best model?

Device fake:FakeFez; front end qiskit; task {"n": 6, "layers": 8, "enc": 1.5707963267948966, "teacher_seed": 4, "teacher_gap": 0.2, "n_train": 64, "n_test": 48}; optimizer {"name": "SPSA", "iterations": 200, "batch": 16, "a": 10.0, "c": 0.4, "A": 2, "init": 0.5, "loop_seed": 1101}; evaluation {"shots": 400, "shot_seed": 20261015, "every": 20, "target_accuracy": 0.7}.

Price: 0.00027 s per shot + 0.036 s per circuit + the circuit's duration per shot, at $1.60 per QPU second (rate: PSF-Zero TIME1 / FRAC1 on ibm_fez (2026-10-14); price: IBM Pay-As-You-Go, 'starts at $96 USD / minute', billed per second (ibm.com/quantum/pricing, 2026-10-15)).

Budget: batch $1626.17, session $1660.98 (what the reference arm qiskit:2:target:template spent on the whole training, plus 5%).

## 1. The result for the money

Accuracy / margin on the test set at the last evaluation within the budget (iteration in brackets); dollars to reach accuracy 0.7; noiseless accuracy of the final angles.

| arm | valid | batch: within budget | session: within budget | $ to target (batch / session) | spent on the whole training (batch / session) | final noiseless accuracy |
|---|---|---|---|---|---|---|
| psfai:template | yes | 0.667 / 0.109 (200) | 0.667 / 0.109 (200) | $906.15 / $931.78 | $1510.24 / $1553.03 | 0.750 |
| qiskit:2:target:template | yes | 0.594 / 0.028 (200) | 0.594 / 0.028 (200) | not reached / not reached | $1548.73 / $1581.89 | 0.542 |

## 2. Reference: classical models, and energy

Not a contest: TOQB compares compilers. The classical models (`toqb.classical`, numpy only, one fixed configuration each) are trained on the same training points and scored on the same test points, as the bar a quantum model is read against. Energy is a range from assumed powers, not a measurement: a quantum run is charged 10-25 kW for the seconds it holds the QPU (time share: the system's whole power for the seconds a run holds the QPU), and every classical second 10-50 W (10-25 kW: wall-plug power of superconducting systems (dilution refrigerators 10-25 kW continuous) as cited in arXiv 2605.09580; 10-50 W: one CPU core, assumed).

| row | test accuracy | time | energy, kWh | money |
|---|---|---|---|---|
| classical: logistic | 0.771 | 0.09 s CPU | 2.5e-07-1.2e-06 | - |
| classical: logistic_quad | 0.750 | 0.08 s CPU | 2.3e-07-1.2e-06 | - |
| classical: mlp32 | 0.771 | 0.47 s CPU | 1.3e-06-6.5e-06 | - |
| classical: knn5 | 0.729 | 0.00 s CPU | 1.7e-09-8.6e-09 | - |
| quantum, batch: psfai:template | 0.667 (iteration 200) | 943.9 s holding the QPU | 2.62-6.56 | $1510.24 |
| quantum, session: psfai:template | 0.667 (iteration 200) | 970.6 s holding the QPU | 2.70-6.74 | $1553.03 |
| quantum, batch: qiskit:2:target:template | 0.594 (iteration 200) | 968.0 s holding the QPU | 2.69-6.72 | $1548.73 |
| quantum, session: qiskit:2:target:template | 0.594 (iteration 200) | 988.7 s holding the QPU | 2.75-6.87 | $1581.89 |

The least energy any quantum row is estimated at is 401,141 times the most any classical model is; the best classical accuracy is 0.771 (logistic).

## 3. The trajectory

iteration: accuracy / margin (dollars spent so far, batch / session)

| arm | evaluations |
|---|---|
| psfai:template | 0: 0.365 / -0.134 ($0.0 / $0.0); 20: 0.438 / -0.009 ($151.0 / $155.2); 40: 0.438 / -0.031 ($302.0 / $310.5); 60: 0.594 / 0.022 ($453.1 / $465.7); 80: 0.573 / 0.026 ($604.1 / $621.3); 100: 0.594 / 0.046 ($755.1 / $776.6); 120: 0.708 / 0.072 ($906.1 / $931.8); 140: 0.625 / 0.077 ($1057.2 / $1087.2); 160: 0.729 / 0.090 ($1208.2 / $1242.4); 180: 0.708 / 0.112 ($1359.2 / $1397.7); 200: 0.667 / 0.109 ($1510.2 / $1553.0) |
| qiskit:2:target:template | 0: 0.344 / -0.119 ($0.0 / $0.0); 20: 0.500 / -0.011 ($154.9 / $158.1); 40: 0.448 / -0.028 ($309.7 / $316.1); 60: 0.469 / 0.004 ($464.6 / $474.2); 80: 0.521 / 0.007 ($619.5 / $632.5); 100: 0.562 / 0.015 ($774.4 / $790.5); 120: 0.469 / 0.001 ($929.2 / $948.7); 140: 0.396 / 0.015 ($1084.1 / $1106.9); 160: 0.448 / 0.011 ($1239.0 / $1265.2); 180: 0.521 / 0.026 ($1393.9 / $1423.5); 200: 0.594 / 0.028 ($1548.7 / $1581.9) |

## 4. Secondary: the cost of compiling

Reference qiskit:2:target:template: 14.16 s per loop.

| arm | version | circuits | compile s | per circuit ms | tier | classical s per loop | templates built / not available | 2q gates | duration us |
|---|---|---|---|---|---|---|---|---|---|
| psfai:template | psf_compile 2026-10-15.c61, psf_ai_compile 2026-10-15.a22 | 6928 | 21.08 | 3.04 | 3x | 26.74 | 1 / 0 | 120.0 | 8.71 |
| qiskit:2:target:template | 2.5.2 | 6928 | 14.16 | 2.04 | 1x | 20.72 | 1 / 0 | 158.0 | 18.11 |

## Checks

- psfai:template: structural failures 0, operations on failed elements 0, equivalence 3 of 3 checked
- qiskit:2:target:template: structural failures 0, operations on failed elements 0, equivalence 3 of 3 checked
