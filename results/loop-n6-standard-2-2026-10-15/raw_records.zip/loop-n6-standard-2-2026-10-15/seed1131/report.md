# TOQB loop standard run 2 n6 L8 (seed 1131): for the same money, which compiler returns the best model?

Device fake:FakeFez; front end qiskit; task {"n": 6, "layers": 8, "enc": 1.5707963267948966, "teacher_seed": 4, "teacher_gap": 0.2, "n_train": 64, "n_test": 48}; optimizer {"name": "SPSA", "iterations": 200, "batch": 16, "a": 10.0, "c": 0.4, "A": 2, "init": 0.5, "loop_seed": 1131}; evaluation {"shots": 400, "shot_seed": 20261015, "every": 20, "target_accuracy": 0.7}.

Price: 0.00027 s per shot + 0.036 s per circuit + the circuit's duration per shot, at $1.60 per QPU second (rate: PSF-Zero TIME1 / FRAC1 on ibm_fez (2026-10-14); price: IBM Pay-As-You-Go, 'starts at $96 USD / minute', billed per second (ibm.com/quantum/pricing, 2026-10-15)).

Budget: batch $1626.17, session $1661.80 (what the reference arm qiskit:2:target:template spent on the whole training, plus 5%).

## 1. The result for the money

Accuracy / margin on the test set at the last evaluation within the budget (iteration in brackets); dollars to reach accuracy 0.7; noiseless accuracy of the final angles.

| arm | valid | batch: within budget | session: within budget | $ to target (batch / session) | spent on the whole training (batch / session) | final noiseless accuracy |
|---|---|---|---|---|---|---|
| psfai:template | yes | 0.625 / 0.030 (200) | 0.625 / 0.030 (200) | $1057.17 / $1087.49 | $1510.24 / $1553.61 | 0.688 |
| qiskit:2:target:template | yes | 0.729 / 0.117 (200) | 0.729 / 0.117 (200) | $1393.86 / $1424.66 | $1548.73 / $1582.66 | 0.750 |

## 2. Reference: classical models, and energy

Not a contest: TOQB compares compilers. The classical models (`toqb.classical`, numpy only, one fixed configuration each) are trained on the same training points and scored on the same test points, as the bar a quantum model is read against. Energy is a range from assumed powers, not a measurement: a quantum run is charged 10-25 kW for the seconds it holds the QPU (time share: the system's whole power for the seconds a run holds the QPU), and every classical second 10-50 W (10-25 kW: wall-plug power of superconducting systems (dilution refrigerators 10-25 kW continuous) as cited in arXiv 2605.09580; 10-50 W: one CPU core, assumed).

| row | test accuracy | time | energy, kWh | money |
|---|---|---|---|---|
| classical: logistic | 0.771 | 0.09 s CPU | 2.5e-07-1.2e-06 | - |
| classical: logistic_quad | 0.750 | 0.09 s CPU | 2.5e-07-1.3e-06 | - |
| classical: mlp32 | 0.771 | 0.46 s CPU | 1.3e-06-6.3e-06 | - |
| classical: knn5 | 0.729 | 0.00 s CPU | 1.9e-09-9.6e-09 | - |
| quantum, batch: psfai:template | 0.625 (iteration 200) | 943.9 s holding the QPU | 2.62-6.56 | $1510.24 |
| quantum, session: psfai:template | 0.625 (iteration 200) | 971.0 s holding the QPU | 2.70-6.74 | $1553.61 |
| quantum, batch: qiskit:2:target:template | 0.729 (iteration 200) | 968.0 s holding the QPU | 2.69-6.72 | $1548.73 |
| quantum, session: qiskit:2:target:template | 0.729 (iteration 200) | 989.2 s holding the QPU | 2.75-6.87 | $1582.66 |

The least energy any quantum row is estimated at is 413,598 times the most any classical model is; the best classical accuracy is 0.771 (logistic).

## 3. The trajectory

iteration: accuracy / margin (dollars spent so far, batch / session)

| arm | evaluations |
|---|---|
| psfai:template | 0: 0.344 / -0.187 ($0.0 / $0.0); 20: 0.625 / 0.010 ($151.0 / $155.2); 40: 0.604 / -0.000 ($302.0 / $310.6); 60: 0.510 / 0.021 ($453.1 / $465.9); 80: 0.448 / -0.006 ($604.1 / $621.3); 100: 0.573 / 0.021 ($755.1 / $776.7); 120: 0.604 / 0.036 ($906.1 / $932.1); 140: 0.719 / 0.042 ($1057.2 / $1087.5); 160: 0.583 / 0.034 ($1208.2 / $1242.9); 180: 0.594 / 0.031 ($1359.2 / $1398.3); 200: 0.625 / 0.030 ($1510.2 / $1553.6) |
| qiskit:2:target:template | 0: 0.281 / -0.156 ($0.0 / $0.1); 20: 0.521 / -0.003 ($154.9 / $158.0); 40: 0.448 / -0.016 ($309.7 / $316.2); 60: 0.438 / -0.007 ($464.6 / $474.5); 80: 0.594 / 0.033 ($619.5 / $633.1); 100: 0.615 / 0.036 ($774.4 / $791.5); 120: 0.615 / 0.045 ($929.2 / $949.8); 140: 0.635 / 0.043 ($1084.1 / $1108.1); 160: 0.646 / 0.061 ($1239.0 / $1266.5); 180: 0.719 / 0.079 ($1393.9 / $1424.7); 200: 0.729 / 0.117 ($1548.7 / $1582.7) |

## 4. Secondary: the cost of compiling

Reference qiskit:2:target:template: 14.89 s per loop.

| arm | version | circuits | compile s | per circuit ms | tier | classical s per loop | templates built / not available | 2q gates | duration us |
|---|---|---|---|---|---|---|---|---|---|
| psfai:template | psf_compile 2026-10-15.c61, psf_ai_compile 2026-10-15.a22 | 6928 | 21.46 | 3.10 | 3x | 27.10 | 1 / 0 | 120.0 | 8.71 |
| qiskit:2:target:template | 2.5.2 | 6928 | 14.89 | 2.14 | 1x | 21.21 | 1 / 0 | 158.0 | 18.11 |

## Checks

- psfai:template: structural failures 0, operations on failed elements 0, equivalence 3 of 3 checked
- qiskit:2:target:template: structural failures 0, operations on failed elements 0, equivalence 3 of 3 checked
