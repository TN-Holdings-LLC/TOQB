# TOQB loop standard run 2 n6 L8 (seed 1100): for the same money, which compiler returns the best model?

Device fake:FakeFez; front end qiskit; task {"n": 6, "layers": 8, "enc": 1.5707963267948966, "teacher_seed": 4, "teacher_gap": 0.2, "n_train": 64, "n_test": 48}; optimizer {"name": "SPSA", "iterations": 200, "batch": 16, "a": 10.0, "c": 0.4, "A": 2, "init": 0.5, "loop_seed": 1100}; evaluation {"shots": 400, "shot_seed": 20261015, "every": 20, "target_accuracy": 0.7}.

Price: 0.00027 s per shot + 0.036 s per circuit + the circuit's duration per shot, at $1.60 per QPU second (rate: PSF-Zero TIME1 / FRAC1 on ibm_fez (2026-10-14); price: IBM Pay-As-You-Go, 'starts at $96 USD / minute', billed per second (ibm.com/quantum/pricing, 2026-10-15)).

Budget: batch $1626.17, session $1660.98 (what the reference arm qiskit:2:target:template spent on the whole training, plus 5%).

## 1. The result for the money

Accuracy / margin on the test set at the last evaluation within the budget (iteration in brackets); dollars to reach accuracy 0.7; noiseless accuracy of the final angles.

| arm | valid | batch: within budget | session: within budget | $ to target (batch / session) | spent on the whole training (batch / session) | final noiseless accuracy |
|---|---|---|---|---|---|---|
| psfai:template | yes | 0.552 / 0.048 (200) | 0.552 / 0.048 (200) | not reached / not reached | $1510.24 / $1552.76 | 0.625 |
| qiskit:2:target:template | yes | 0.719 / 0.087 (200) | 0.719 / 0.087 (200) | $1238.98 / $1265.72 | $1548.73 / $1581.88 | 0.729 |

## 2. Reference: classical models, and energy

Not a contest: TOQB compares compilers. The classical models (`toqb.classical`, numpy only, one fixed configuration each) are trained on the same training points and scored on the same test points, as the bar a quantum model is read against. Energy is a range from assumed powers, not a measurement: a quantum run is charged 10-25 kW for the seconds it holds the QPU (time share: the system's whole power for the seconds a run holds the QPU), and every classical second 10-50 W (10-25 kW: wall-plug power of superconducting systems (dilution refrigerators 10-25 kW continuous) as cited in arXiv 2605.09580; 10-50 W: one CPU core, assumed).

| row | test accuracy | time | energy, kWh | money |
|---|---|---|---|---|
| classical: logistic | 0.771 | 0.07 s CPU | 1.8e-07-9e-07 | - |
| classical: logistic_quad | 0.750 | 0.08 s CPU | 2.3e-07-1.2e-06 | - |
| classical: mlp32 | 0.771 | 0.43 s CPU | 1.2e-06-6e-06 | - |
| classical: knn5 | 0.729 | 0.00 s CPU | 1.2e-09-5.8e-09 | - |
| quantum, batch: psfai:template | 0.552 (iteration 200) | 943.9 s holding the QPU | 2.62-6.56 | $1510.24 |
| quantum, session: psfai:template | 0.552 (iteration 200) | 970.5 s holding the QPU | 2.70-6.74 | $1552.76 |
| quantum, batch: qiskit:2:target:template | 0.719 (iteration 200) | 968.0 s holding the QPU | 2.69-6.72 | $1548.73 |
| quantum, session: qiskit:2:target:template | 0.719 (iteration 200) | 988.7 s holding the QPU | 2.75-6.87 | $1581.88 |

The least energy any quantum row is estimated at is 434,038 times the most any classical model is; the best classical accuracy is 0.771 (logistic).

## 3. The trajectory

iteration: accuracy / margin (dollars spent so far, batch / session)

| arm | evaluations |
|---|---|
| psfai:template | 0: 0.333 / -0.199 ($0.0 / $0.0); 20: 0.448 / -0.020 ($151.0 / $155.4); 40: 0.385 / -0.014 ($302.0 / $310.8); 60: 0.448 / -0.011 ($453.1 / $466.1); 80: 0.562 / 0.019 ($604.1 / $621.3); 100: 0.562 / 0.027 ($755.1 / $776.5); 120: 0.604 / 0.061 ($906.1 / $931.8); 140: 0.521 / 0.038 ($1057.2 / $1087.1); 160: 0.604 / 0.048 ($1208.2 / $1242.1); 180: 0.510 / 0.039 ($1359.2 / $1397.5); 200: 0.552 / 0.048 ($1510.2 / $1552.8) |
| qiskit:2:target:template | 0: 0.302 / -0.162 ($0.0 / $0.1); 20: 0.469 / -0.015 ($154.9 / $158.2); 40: 0.438 / -0.021 ($309.7 / $316.4); 60: 0.510 / -0.006 ($464.6 / $474.6); 80: 0.625 / 0.028 ($619.5 / $633.0); 100: 0.562 / 0.036 ($774.4 / $791.0); 120: 0.677 / 0.043 ($929.2 / $949.2); 140: 0.646 / 0.048 ($1084.1 / $1107.6); 160: 0.750 / 0.078 ($1239.0 / $1265.7); 180: 0.667 / 0.082 ($1393.9 / $1423.9); 200: 0.719 / 0.087 ($1548.7 / $1581.9) |

## 4. Secondary: the cost of compiling

Reference qiskit:2:target:template: 14.39 s per loop.

| arm | version | circuits | compile s | per circuit ms | tier | classical s per loop | templates built / not available | 2q gates | duration us |
|---|---|---|---|---|---|---|---|---|---|
| psfai:template | psf_compile 2026-10-15.c61, psf_ai_compile 2026-10-15.a22 | 6928 | 20.91 | 3.02 | 3x | 26.57 | 1 / 0 | 120.0 | 8.71 |
| qiskit:2:target:template | 2.5.2 | 6928 | 14.39 | 2.07 | 1x | 20.72 | 1 / 0 | 158.0 | 18.11 |

## Checks

- psfai:template: structural failures 0, operations on failed elements 0, equivalence 3 of 3 checked
- qiskit:2:target:template: structural failures 0, operations on failed elements 0, equivalence 3 of 3 checked
