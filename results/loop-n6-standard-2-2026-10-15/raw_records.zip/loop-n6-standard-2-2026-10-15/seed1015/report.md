# TOQB loop standard run 2 n6 L8 (seed 1015): for the same money, which compiler returns the best model?

Device fake:FakeFez; front end qiskit; task {"n": 6, "layers": 8, "enc": 1.5707963267948966, "teacher_seed": 4, "teacher_gap": 0.2, "n_train": 64, "n_test": 48}; optimizer {"name": "SPSA", "iterations": 200, "batch": 16, "a": 10.0, "c": 0.4, "A": 2, "init": 0.5, "loop_seed": 1015}; evaluation {"shots": 400, "shot_seed": 20261015, "every": 20, "target_accuracy": 0.7}.

Price: 0.00027 s per shot + 0.036 s per circuit + the circuit's duration per shot, at $1.60 per QPU second (rate: PSF-Zero TIME1 / FRAC1 on ibm_fez (2026-10-14); price: IBM Pay-As-You-Go, 'starts at $96 USD / minute', billed per second (ibm.com/quantum/pricing, 2026-10-15)).

Budget: batch $1626.17, session $1664.54 (what the reference arm qiskit:2:target:template spent on the whole training, plus 5%).

## 1. The result for the money

Accuracy / margin on the test set at the last evaluation within the budget (iteration in brackets); dollars to reach accuracy 0.7; noiseless accuracy of the final angles.

| arm | valid | batch: within budget | session: within budget | $ to target (batch / session) | spent on the whole training (batch / session) | final noiseless accuracy |
|---|---|---|---|---|---|---|
| psfai:template | yes | 0.740 / 0.279 (200) | 0.740 / 0.279 (200) | $151.02 / $155.51 | $1510.24 / $1554.41 | 0.708 |
| qiskit:2:target:template | yes | 0.677 / 0.198 (200) | 0.677 / 0.198 (200) | $154.87 / $158.37 | $1548.73 / $1585.28 | 0.750 |

## 2. Reference: classical models, and energy

Not a contest: TOQB compares compilers. The classical models (`toqb.classical`, numpy only, one fixed configuration each) are trained on the same training points and scored on the same test points, as the bar a quantum model is read against. Energy is a range from assumed powers, not a measurement: a quantum run is charged 10-25 kW for the seconds it holds the QPU (time share: the system's whole power for the seconds a run holds the QPU), and every classical second 10-50 W (10-25 kW: wall-plug power of superconducting systems (dilution refrigerators 10-25 kW continuous) as cited in arXiv 2605.09580; 10-50 W: one CPU core, assumed).

| row | test accuracy | time | energy, kWh | money |
|---|---|---|---|---|
| classical: logistic | 0.771 | 0.07 s CPU | 2e-07-1e-06 | - |
| classical: logistic_quad | 0.750 | 0.09 s CPU | 2.4e-07-1.2e-06 | - |
| classical: mlp32 | 0.771 | 0.45 s CPU | 1.3e-06-6.3e-06 | - |
| classical: knn5 | 0.729 | 0.00 s CPU | 1.6e-09-8e-09 | - |
| quantum, batch: psfai:template | 0.740 (iteration 200) | 943.9 s holding the QPU | 2.62-6.56 | $1510.24 |
| quantum, session: psfai:template | 0.740 (iteration 200) | 971.5 s holding the QPU | 2.70-6.75 | $1554.41 |
| quantum, batch: qiskit:2:target:template | 0.677 (iteration 200) | 968.0 s holding the QPU | 2.69-6.72 | $1548.73 |
| quantum, session: qiskit:2:target:template | 0.677 (iteration 200) | 990.8 s holding the QPU | 2.75-6.88 | $1585.28 |

The least energy any quantum row is estimated at is 415,364 times the most any classical model is; the best classical accuracy is 0.771 (logistic).

## 3. The trajectory

iteration: accuracy / margin (dollars spent so far, batch / session)

| arm | evaluations |
|---|---|
| psfai:template | 0: 0.281 / -0.161 ($0.0 / $0.0); 20: 0.729 / 0.141 ($151.0 / $155.5); 40: 0.615 / 0.192 ($302.0 / $311.1); 60: 0.667 / 0.212 ($453.1 / $466.6); 80: 0.677 / 0.235 ($604.1 / $621.8); 100: 0.740 / 0.249 ($755.1 / $777.3); 120: 0.760 / 0.278 ($906.1 / $932.9); 140: 0.750 / 0.282 ($1057.2 / $1088.1); 160: 0.760 / 0.294 ($1208.2 / $1243.4); 180: 0.740 / 0.284 ($1359.2 / $1399.1); 200: 0.740 / 0.279 ($1510.2 / $1554.4) |
| qiskit:2:target:template | 0: 0.281 / -0.142 ($0.0 / $0.0); 20: 0.729 / 0.058 ($154.9 / $158.4); 40: 0.677 / 0.164 ($309.7 / $316.6); 60: 0.604 / 0.163 ($464.6 / $474.9); 80: 0.708 / 0.195 ($619.5 / $633.5); 100: 0.656 / 0.200 ($774.4 / $792.3); 120: 0.708 / 0.209 ($929.2 / $951.0); 140: 0.708 / 0.213 ($1084.1 / $1109.6); 160: 0.604 / 0.197 ($1239.0 / $1268.0); 180: 0.719 / 0.208 ($1393.9 / $1426.8); 200: 0.677 / 0.198 ($1548.7 / $1585.3) |

## 4. Secondary: the cost of compiling

Reference qiskit:2:target:template: 16.03 s per loop.

| arm | version | circuits | compile s | per circuit ms | tier | classical s per loop | templates built / not available | 2q gates | duration us |
|---|---|---|---|---|---|---|---|---|---|
| psfai:template | psf_compile 2026-10-15.c61, psf_ai_compile 2026-10-15.a22 | 6928 | 21.77 | 3.14 | 3x | 27.60 | 1 / 0 | 120.0 | 8.71 |
| qiskit:2:target:template | 2.5.2 | 6928 | 16.03 | 2.31 | 1x | 22.84 | 1 / 0 | 158.0 | 18.11 |

## Checks

- psfai:template: structural failures 0, operations on failed elements 0, equivalence 3 of 3 checked
- qiskit:2:target:template: structural failures 0, operations on failed elements 0, equivalence 3 of 3 checked
