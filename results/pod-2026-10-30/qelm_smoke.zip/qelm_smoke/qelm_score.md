# QELM prototype on simulators (REHEARSAL: noiseless reference and a fake-backend stand-in; not a device result; nothing chosen from these numbers)

- R1 baselines: least squares on the raw inputs 0.545; on the noiseless quantum features (this model's ceiling) 0.935

| arm | CZ / circuit | median lambda (X, Y, Z) | Q1 chi2/dof median, share > 2 | S 16: acc [99 % band] | S 32: acc [99 % band] | S 64: acc [99 % band] | S 125: acc [99 % band] | S 250: acc [99 % band] |
|---|---|---|---|---|---|---|---|---|
| fold:rule | 48 | 0.843, 0.856, 0.898 | 2.09, 0.58 | 0.695 [0.680, 0.850] | 0.765 [0.735, 0.885] | 0.860 [0.795, 0.910] | 0.840 [0.840, 0.940] | 0.880 [0.870, 0.955] |
| fold:zipcyc | 48 | 0.874, 0.809, 0.882 | 2.32, 0.71 | 0.730 [0.660, 0.825] | 0.805 [0.725, 0.875] | 0.855 [0.800, 0.910] | 0.860 [0.835, 0.930] | 0.895 [0.875, 0.950] |

Paired differences (McNemar, two-sided; first arm right only / second arm right only, p):

- S 16: fold:rule vs fold:zipcyc: 31 / 38, p 0.47
- S 32: fold:rule vs fold:zipcyc: 20 / 28, p 0.31
- S 64: fold:rule vs fold:zipcyc: 21 / 20, p 1
- S 125: fold:rule vs fold:zipcyc: 18 / 22, p 0.64
- S 250: fold:rule vs fold:zipcyc: 13 / 16, p 0.71
