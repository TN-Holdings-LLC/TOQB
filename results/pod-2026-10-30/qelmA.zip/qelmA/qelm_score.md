# QELM prototype on simulators (REHEARSAL: noiseless reference and a fake-backend stand-in; not a device result; nothing chosen from these numbers)

- R1 baselines: least squares on the raw inputs 0.555; on the noiseless quantum features (this model's ceiling) 0.840

| arm | CZ / circuit | median lambda (X, Y, Z) | Q1 chi2/dof median, share > 2 | S 16: acc [99 % band] | S 32: acc [99 % band] | S 64: acc [99 % band] | S 125: acc [99 % band] | S 250: acc [99 % band] |
|---|---|---|---|---|---|---|---|---|
| fold:rule | 380 | 0.578, 0.576, 0.729 | 1.47, 0.18 | 0.585 [0.530, 0.740] | 0.670 [0.600, 0.765] | 0.695 [0.645, 0.825] | 0.780 [0.695, 0.855] | 0.840 [0.740, 0.885] |
| fold:zipcyc | 874 | 0.222, 0.214, 0.444 | 1.38, 0.25 | 0.560 [0.485, 0.680] | 0.635 [0.530, 0.715] | 0.690 [0.570, 0.740] | 0.765 [0.600, 0.780] | 0.785 [0.640, 0.810] |

Paired differences (McNemar, two-sided; first arm right only / second arm right only, p):

- S 16: fold:rule vs fold:zipcyc: 49 / 44, p 0.68
- S 32: fold:rule vs fold:zipcyc: 44 / 37, p 0.51
- S 64: fold:rule vs fold:zipcyc: 35 / 34, p 1
- S 125: fold:rule vs fold:zipcyc: 37 / 34, p 0.81
- S 250: fold:rule vs fold:zipcyc: 31 / 20, p 0.16
